import React, { useState } from "react";

const Admin = () => {
  const [message] = useState("Em breve: painel completo para adicionar/remover produtos.");
  return (
    <div className="bg-gray-900 p-6 rounded-xl text-center text-white">
      <h2 className="text-2xl font-bold mb-4">Painel Administrativo</h2>
      <p className="text-gray-400">{message}</p>
    </div>
  );
};

export default Admin;
