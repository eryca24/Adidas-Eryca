import React from "react";

const products = [
  {
    id: 1,
    name: "Jaqueta Adidas Verde",
    price: "R$ 299,00",
    image: "https://via.placeholder.com/300x400?text=Produto+1",
  },
  {
    id: 2,
    name: "Tênis Azul Marinho",
    price: "R$ 399,00",
    image: "https://via.placeholder.com/300x400?text=Produto+2",
  },
  {
    id: 3,
    name: "Camiseta Preta Estilizada",
    price: "R$ 149,00",
    image: "https://via.placeholder.com/300x400?text=Produto+3",
  },
];

const Catalog = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      {products.map((product) => (
        <div
          key={product.id}
          className="bg-white text-black rounded-2xl overflow-hidden shadow-lg"
        >
          <img src={product.image} alt={product.name} className="w-full h-80 object-cover" />
          <div className="p-4">
            <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
            <p className="mb-4 text-gray-700">{product.price}</p>
            <a
              href={`https://wa.me/5551995554158?text=Olá! Quero comprar a peça: ${product.name}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
            >
              Comprar no WhatsApp
            </a>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Catalog;
