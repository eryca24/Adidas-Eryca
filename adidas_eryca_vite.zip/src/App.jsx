import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import Catalog from "./Catalog";
import Admin from "./Admin";

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white font-sans">
        <header className="p-4 flex justify-between items-center border-b border-gray-700">
          <h1 className="text-2xl font-bold text-white">Adidas Eryca</h1>
          <nav className="space-x-4">
            <Link to="/" className="hover:text-red-500">Catálogo</Link>
            <Link to="/admin" className="hover:text-red-500">Admin</Link>
          </nav>
        </header>
        <main className="p-6">
          <Routes>
            <Route path="/" element={<Catalog />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
