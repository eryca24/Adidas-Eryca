import React, { useState, useEffect } from "react";

export default function Admin() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ name: "", description: "", image: "" });

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("products")) || [];
    setProducts(stored);
  }, []);

  const handleAdd = () => {
    const updated = [...products, form];
    setProducts(updated);
    localStorage.setItem("products", JSON.stringify(updated));
    setForm({ name: "", description: "", image: "" });
  };

  const handleDelete = (index) => {
    const updated = products.filter((_, i) => i !== index);
    setProducts(updated);
    localStorage.setItem("products", JSON.stringify(updated));
  };

  return (
    <div>
      <h2>Adicionar Nova Peça</h2>
      <input
        placeholder="Nome"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />
      <input
        placeholder="Descrição"
        value={form.description}
        onChange={(e) => setForm({ ...form, description: e.target.value })}
      />
      <input
        placeholder="URL da imagem"
        value={form.image}
        onChange={(e) => setForm({ ...form, image: e.target.value })}
      />
      <button onClick={handleAdd}>Adicionar</button>

      <h2>Peças Cadastradas</h2>
      <ul>
        {products.map((p, i) => (
          <li key={i}>
            {p.name} - {p.description}
            <button onClick={() => handleDelete(i)}>Remover</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
