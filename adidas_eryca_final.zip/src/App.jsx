import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Catalog from "./Catalog";
import Admin from "./Admin";

export default function App() {
  return (
    <BrowserRouter>
      <header style={styles.header}>
        <h1 style={styles.logo}>Adidas Eryca</h1>
        <nav>
          <Link style={styles.link} to="/">Catálogo</Link>
          <Link style={styles.link} to="/admin">Painel Admin</Link>
        </nav>
      </header>
      <main style={styles.main}>
        <Routes>
          <Route path="/" element={<Catalog />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

const styles = {
  header: {
    backgroundColor: "#0f172a",
    color: "#fff",
    padding: "1rem",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  logo: {
    margin: 0
  },
  link: {
    color: "#fff",
    marginLeft: "1rem",
    textDecoration: "none",
    fontWeight: "bold"
  },
  main: {
    padding: "1rem"
  }
};
