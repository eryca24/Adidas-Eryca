import React, { useEffect, useState } from "react";

export default function Catalog() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("products")) || [];
    setProducts(stored);
  }, []);

  return (
    <div style={styles.grid}>
      {products.map((product, index) => (
        <div key={index} style={styles.card}>
          <img src={product.image || "https://via.placeholder.com/200"} alt={product.name} style={styles.image} />
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          <button onClick={() => window.open("https://wa.me/5551995554158", "_blank")} style={styles.button}>Comprar</button>
        </div>
      ))}
    </div>
  );
}

const styles = {
  grid: {
    display: "grid",
    gap: "1rem",
    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))"
  },
  card: {
    backgroundColor: "#f1f5f9",
    padding: "1rem",
    borderRadius: "10px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
    textAlign: "center"
  },
  image: {
    width: "100%",
    height: "200px",
    objectFit: "cover",
    borderRadius: "8px"
  },
  button: {
    marginTop: "0.5rem",
    padding: "0.5rem 1rem",
    backgroundColor: "#0f172a",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer"
  }
};
